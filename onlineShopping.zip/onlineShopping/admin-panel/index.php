<?php include '../connect/db.php'; ?>
<?php include '../connect/functions.php'; ?>
<?php 
	if (!isset($_SESSION['admin_login'])) {
		?>
		<script>
			window.location="../login.php";
					</script>
		<?php
	}else{
 ?>
 <!DOCTYPE html>
<html lang="en">
	<head>
	<?php include '../links/head.php'; ?>
	</head>
	<body>
				<?php include 'inc/nav.php'; ?>
				<div class="container">
				<?php ($get_nav_data)?include $page:''; ?>
				</div><!-- container -->

		<?php include '../links/foot.php'; ?>
		<script>
			$(document).ready(function(){
		// $( "#products" ).submit(function( event ) {
			  $(".alert").fadeOut(6000);
			
			//});				
			});//ready
		</script>
	</body>
</html>
<?php } ?>