	<?php 
	if (isset($_REQUEST['add_product'])) {
		$product_title = $_REQUEST['product_title'];
		$product_price = $_REQUEST['product_price'];
		$product_desc = $_REQUEST['product_desc'];
		$cat_id= $_REQUEST['cat_id'];
		$brand_id = $_REQUEST['brand_id'];
		$status="on";
		$product_keywords = $_REQUEST['product_keywords'];

		//get images
		$product_img1 = $_FILES['product_img1']['name'];
		$product_img2 = $_FILES['product_img2']['name'];
		$product_img3 = $_FILES['product_img3']['name'];
		//get img tmp_name
		$tmp_img1  = $_FILES['product_img1']['tmp_name'];
		$tmp_img2  = $_FILES['product_img2']['tmp_name'];
		$tmp_img3  = $_FILES['product_img3']['tmp_name'];
		if ($product_img1=='' OR $product_title=='' OR $product_price=='' OR $product_desc=='' OR $cat_id=='' OR $brand_id=='' ) {
			 echo "<script>alert('Please Fill All the Fields...');</script>";
			 exit();
		}else{
			move_uploaded_file($tmp_img1, 'product_images/'.$product_img1);
			move_uploaded_file($tmp_img2, 'product_images/'.$product_img2);
			move_uploaded_file($tmp_img3, 'product_images/'.$product_img3);
			$q = "INSERT INTO products(cat_id,brand_id,product_title,product_price,product_desc,product_img1,product_img2,product_img3,adate,status,product_keywords) VALUES('$cat_id','$brand_id','$product_title','$product_price','$product_desc','$product_img1','$product_img2','$product_img3',NOW(),'$status','$product_keywords')";
			$r = mysqli_query($dbc,$q);
			if ($r) {
				$msg =  "Record Added..";
				$sts = "success";
			}else{
				$msg =  mysqli_error($dbc);
				$sts = "danger";
			}

		}

	}
	 ?>
	<?php 
		if (!empty($msg)) {
			echo "<div class='alert alert-{$sts}'>{$msg}</div>";
		}
	?>	
<h1>Products</h1>
<hr>
<form method="post" enctype="multipart/form-data" id="products">
	<div class="panel panel-default">
		<div class="panel-body">
			<div class="row">
				<div class="col-sm-4">
					<div class="form-group"><label for="">Product Title</label><input type="text" class="form-control" name="product_title" placeholder="Product Title..."></div>
					<div class="form-group"><label for="">Category</label>
						<select name="cat_id" class="form-control" id="">
							<option>Select Category</option>
							<?php 
							$cat = mysqli_query($dbc,"SELECT * FROM categories");
							while ($cat_r = mysqli_fetch_assoc($cat)) {
						 ?>
						<option value="<?php echo $cat_r['cat_id'];?>"><?php echo $cat_r['cat_title'];?></option>
						<?php } //category while ends ?>
						</select>
					</div>
					<div class="form-group"><label for="">Brand</label>
						<select name="brand_id" class="form-control" id="">
							<option>Select Category</option>
							<?php 
							$brand = mysqli_query($dbc,"SELECT * FROM brands");
							while ($brand_r = mysqli_fetch_assoc($brand)) {
						 ?>
						<option value="<?php echo $brand_r['brand_id'];?>"><?php echo $brand_r['brand_title'];?></option>
						<?php } //category while ends ?>
						</select>
					</div>
					<div class="form-group"><label for="">Product Price</label><input type="text" class="form-control" name="product_price" placeholder="Product Price..."></div>
					<div class="form-group">
					<label>Keywords</label>
					<input name="product_keywords" type="text" placeholder="Add Keyword to help in search process" class="form-control">
				</div>	
				</div>
				<div class="col-sm-6">
				<fieldset>
					<legend>Select Product's Pictures</legend>
					<label>Picture 1</label> <input type="file" name="product_img1">
					<label>Picture 2</label> <input type="file" name="product_img2">
					<label>Picture 3</label> <input type="file" name="product_img3">
				</fieldset>
				<hr>	
				
				<div class="form-group">
					<label>Description</label>
					<textarea name="product_desc" rows="5" class="form-control"></textarea>
				</div>	
					

				</div><!-- col 2 -->
				<div class="col-sm-2">
					<div class="panel panel-default">
						<div class="panel-body">
						<h4>Actions</h4>
						<hr>
							<button class="btn btn-success" type="submit" name="add_product"><i class="glyphicon glyphicon-ok"></i></button>
						</div>
					</div>
				</div>
			</div><!-- row -->
		</div><!-- panel-body -->
	</div><!-- panel panel-default -->
</form>