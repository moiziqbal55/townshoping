<?php 
	if (isset($_REQUEST['add_video'])) {
		$title = mysqli_real_escape_string($dbc,strip_tags($_REQUEST['title']));
		$src = mysqli_real_escape_string($dbc,strip_tags($_REQUEST['src']));
		$description = mysqli_real_escape_string($dbc,strip_tags($_REQUEST['description']));
		$add_date = date('d-M-Y');
		
		$chk = mysqli_query($dbc,"SELECT * FROM videos WHERE title='$title'");
		if ( mysqli_num_rows($chk)>=1 ) {
			$msg = "Duplication Title Not Allowed...";
			$sts = "warning";
		}else{

		$q = "INSERT INTO videos(id,title,src,description,add_date) VALUES('','$title','$src','$description','$add_date')";
		$r = mysqli_query($dbc,$q);
		if ($r) {
			$msg="Video Added..";
			$sts="success";
		}else{
			$msg ="Prolem in Query...";
			$sts ="danger";
		}
	}//not duplication else close
	
	}//insert daat if close
 ?>
 <?php 	
 	if (!empty($_REQUEST['del_id'])) {
 		$del_id = $_REQUEST['del_id'];
 		?>
 			<form method="post">
 				<div class="radio">
 				<h4 class="text-muted">Do You Really Want to Delete ?</h4>
 					<label>
 						<input type="radio" value="yes" name="choice">
 						Yes
 					</label> |
 					<label>
 						<input type="radio" value="no" name="choice">
 						No
 					</label>
 					<button type="submit" name="del_choice" class="btn btn-danger btn-sm">Delete</button>
 				</div>
 			</form>
 		<?php
 		if (isset($_REQUEST['del_choice'])) {
 			$choice = $_REQUEST['choice'];
 			if ($choice=='yes') {
 				$q  = mysqli_query($dbc,"DELETE FROM videos WHERE id='$del_id'");
 				if ($q) {
					$msg="Video Deleted..";
					$sts="danger";
					header('refresh:2;url=?nav=video');
				}else{
					$msg ="Prolem in Query...";
					$sts ="danger";
				}
 			}//choise yes if close
 			else{
			header('location:?nav=video');
 			}//choice no close
 		}//form del_choice button if close
 	}//main del_id if close
  ?>

  <?php 
  	if (!empty($_REQUEST['update_id'])) {
  		$update_id = $_REQUEST['update_id'];
  		$fetch_video = mysqli_fetch_assoc(mysqli_query($dbc,"SELECT * FROM videos WHERE id='$update_id'"));

  	}

   ?>
   <?php 
	if (isset($_REQUEST['update_video'])) {
		$title = mysqli_real_escape_string($dbc,strip_tags($_REQUEST['title']));
		$src = mysqli_real_escape_string($dbc,strip_tags($_REQUEST['src']));
		$description = mysqli_real_escape_string($dbc,strip_tags($_REQUEST['description']));
		$chk = mysqli_query($dbc,"SELECT * FROM videos WHERE src='$src'");
		if ( mysqli_num_rows($chk)>=1 ) {
			$msg = "Duplication Title Not Allowed...";
			$sts = "warning";
		}else{

		$q = "UPDATE videos SET title='$title' , src ='$src' , description ='$description' WHERE id='$update_id'";
		$r = mysqli_query($dbc,$q);
		if ($r) {
			$msg="Video Updated..";
			$sts="success";
		}else{
			$msg ="Prolem in Query...";
			$sts ="danger";
		}
	}//not duplication else close
	
	}//insert daat if close
 ?>
<h1>Video Page</h1>
<hr>
<div class="row">
	<div class="col-sm-8">
	<div class="table-responsive">
		<table class="table table-hover table-striped table-bordered">
			<tr>
				<th>ID</th>
				<th>Title</th>
				<th>src</th>
				<th>Description</th>
				<th colspan="100">Edit</th>
			</tr>
			<?php 
			$q = mysqli_query($dbc,"SELECT * FROM videos");
			$count = mysqli_num_rows($q);
			while ($video  = mysqli_fetch_assoc($q) ) {
				# code...
			?>
			<tr>
				<td><?php echo $video['id'];?></td>
				<td><?php echo $video['title'];?></td>
				<td><?php echo $video['src'];?></td>
				<td><?php echo $video['description'];?></td>
				<td><a href="?nav=video&amp;del_id=<?php echo $video['id']; ?>"><i style="color:red" class="glyphicon glyphicon-trash"></i></a></td>
				<td><a href="?nav=video&amp;update_id=<?php echo $video['id']; ?>""><i class="glyphicon glyphicon-pencil"></i></a></td>

			</tr>
			<?php 
		}//while loop
			 ?>
		</table>
		</div>
		<div class="well">Total Videos: <?php echo $count; ?></div>
	
	</div><!-- col -->
	<div class="col-sm-4">
	<?php 
		if (!empty($msg)) {
			echo "<div class='alert alert-{$sts}'>{$msg}</div>";
		}
	 ?>
			<h4>Insert Data</h4>
			<hr>
			<form method="post">
			<?php if (!empty($_REQUEST['update_id'])) { ?>
				<button class="btn btn-primary" type="submit" name="update_video"><i class="glyphicon glyphicon-pencil"></i></button>			
			<?php }else{ ?>
			<button class="btn btn-success" type="submit" name="add_video"><i class="glyphicon glyphicon-ok"></i></button>
			<?php } ?>

			<hr>
				<div class="form-group">
					<label>Title</label>
					<input type="text" value="<?php if(!empty($fetch_video['title'])){
						echo $fetch_video['title'];
						} ?>" required placeholder="Title..." name="title" class="form-control">
				</div>
				<div class="form-group">
					<label>Src</label>
					<input type="text" value="<?php if(!empty($fetch_video['src'])){
						echo htmlentities($fetch_video['src']);
						} ?>" required placeholder="Source..." name="src" class="form-control">
				</div>
				<div class="form-group">
					<label>Description</label>
					<textarea name="description" class="form-control" rows="10"><?php if(!empty($fetch_video['description'])){
						echo $fetch_video['description'];
						} ?>
					</textarea>
				</div>
			</form>
	</div><!-- col thumbnails -->

</div><!-- row -->