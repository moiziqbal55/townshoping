<?php 
	include '../connect/db.php';
	$email = $_REQUEST['em'];
	$password = $_REQUEST['ps'];
	if ($email AND $password ) {
		$_SESSION['temp_email'] =$email;
		$admin = mysqli_query($dbc,"SELECT * FROM admin WHERE email='$email' AND password='$password'");
		
		$customers = mysqli_query($dbc,"SELECT * FROM customers WHERE email='$email' AND password='$password'");

		if (mysqli_num_rows($admin)==1) {
			echo "<div class='alert alert-success'>Loggin...</div>";
			$_SESSION['admin_login'] = $email;
			?>
			<script>
				setTimeout(function(){
					window.location='admin-panel/';
				},1000);
			</script>
			<?php
		}else if (mysqli_num_rows($customers)==1) {
					echo "<div class='alert alert-success'>Loggin...</div>";
					$_SESSION['customer_login'] = $email;
					?>
					<script>
						setTimeout(function(){
							window.location='customers/';
						},1000);
					</script>
					<?php
				}else{
			echo "<div class='alert alert-danger'>Invalid Email Or Password...</div>";
		}
	}


 ?>