<?php 
session_start();
	$dbc = mysqli_connect('localhost','root','','myshop');
 ?>