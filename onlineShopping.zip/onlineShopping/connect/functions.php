<?php 
	function getPro($dbc,$table,$cat_id="",$brand_id="",$search=""){
					
			if (empty($search)) {
					if (empty($cat_id) AND empty($brand_id)) {
					$products = mysqli_query($dbc,"SELECT * FROM $table ORDER BY rand() LIMIT 0,6");
					}else{
					$products = mysqli_query($dbc,"SELECT * FROM $table WHERE cat_id='$cat_id' OR brand_id='$brand_id' ORDER BY rand() LIMIT 0,6");
						}
			}//empty Search
			else{
		$products = mysqli_query($dbc,"SELECT * FROM $table WHERE product_title LIKE '%$search%'");
	
			}
				
					if (mysqli_num_rows($products)==0) {
							echo "<h2 class='text-center text-muted'>No Data Found</h2>";
						}
					while ($product = mysqli_fetch_assoc($products)) {
						# code...
						$p_id = $product['product_id'];
						$p_title = $product['product_title'];
						$cat_id = $product['cat_id'];
						$brand_id = $product['brand_id'];
						$p_desc= $product['product_desc'];
						$p_img1 = $product['product_img1'];
						$p_price = $product['product_price'];
						

					 ?>
						<div class="col-sm-3">
							<div class="thumbnail">
							<img src="admin-panel/product_images/<?php echo $p_img1;?>" alt="">
							<hr>
								<div class="caption">
									<h5><?php echo ucwords($p_title);?></h5>
									<p><b>Price : <?= $p_price;?> PKR</b></p>
									<hr>
									<a href="details.php?pro_id=<?php echo $p_id;?>"><button type="button" class="btn btn-primary btn-xs">Detail</button></a>
									<a href="?add_cart=<?php echo $p_id;?>"><button type="button" class="btn btn-warning btn-xs">Add Cart <span class="glyphicon glyphicon-shopping-cart"></span></button> </a>

								</div>
							</div>
						</div>
						<?php } 
			

	}//function ends
 ?>

 		<?php 
 			function getCat($dbc,$table){
 				?>
 					<div class="list-group">
						<div class="list-group-item disabled">Category</div>
						<?php 
						
						$cat = mysqli_query($dbc,"SELECT * FROM $table");

							while ($cat_r = mysqli_fetch_assoc($cat)) {
									$count = mysqli_num_rows( mysqli_query($dbc,"SELECT * FROM products WHERE cat_id='$cat_r[cat_id]'"));
						 ?>
						<a href="?cat_id=<?php echo $cat_r['cat_id'];?>" class="list-group-item <?php if($_REQUEST['cat_id']==$cat_r['cat_id']){echo "active";} ?>"><?php echo $cat_r['cat_title'];?>  <span class="badge"><?php echo $count; ?></span></a>
						<?php } //category while ends ?>
					</div><!-- category -->

 			<?php 
 		}//function category ends
 		 ?>

 		 <?php 	
 		 	function getBrands($dbc,$table){
 		 		?>
 		 		<div class="list-group">
						<div class="list-group-item disabled">Brands</div>
						<?php 
							$brand = mysqli_query($dbc,"SELECT * FROM $table");
							while ($brand_r = mysqli_fetch_assoc($brand)) {
								$count = mysqli_num_rows( mysqli_query($dbc,"SELECT * FROM products WHERE brand_id='$brand_r[brand_id]'"));
						 ?>
						<a href="?brand_id=<?php echo $brand_r['brand_id'];?>" class="list-group-item <?php if($_REQUEST['brand_id']==$brand_r['brand_id']){echo "active";} ?>"><?php echo $brand_r['brand_title'];?> <span class="badge"><?php echo $count; ?></span></a>
						<?php } //category while ends ?>
					</div><!-- brands -->
 		 	<?php 
 		}//function brands ends
 		 ?>