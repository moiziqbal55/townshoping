  <footer class="footer">
      <div class="container">
      <center>
      <br>
    <ul class="list-inline">
    	<li><a href="?nav=term-and-conditions">Terms &amp; Conditions</a></li>
    	<li><a href="">Shipping</a></li>
    	<li><a href="?nav=privacy">Privacy Policy</a></li>
    </ul>
        <p class="text-muted">

		© 2016 <i class="text-red">*Town Shoping*</i>. All rights reserved.

		Powered by <i class="text-red">Town Shoping</i> free shopping cart
		</p>
		</center>
      </div>
    </footer>