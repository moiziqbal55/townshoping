<div class="container">
<div style="background: #f5f5f5;" class="row">
	<div class="col-sm-2 col-sm-offset-10">
		<ul class="list-inline">
			<li><a data-toggle="modal" href="#login_form">Sign In</a></li>
			<li><a href="">|</a></li>
			<li><a href="">Join</a></li>
		</ul>
	</div>	
</div>
</div><!-- container -->
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<img src="img/logo.png" width="110" height="100" alt="">
				</div><!-- logo col -->
				<div class="col-sm-4">
				<br><br>
					<ul class="nav nav-tabs">
						<li class="active"><a style="cursor:pointer" class="text-center" href=""><span class="glyphicon glyphicon-earphone"></span> <br>03-000-000-000</a></li>
						<li class="active"><a style="cursor:pointer" class="text-center" href=""><span class="glyphicon glyphicon-user"></span> <br>My Account !</a></li>
						<li class="active"><a style="cursor:pointer" class="text-center" href=""><span class="glyphicon glyphicon-shopping-cart"></span> <br>Cart</a></li>
					</ul>
				</div><!-- right col -->
			</div><!-- row -->
		</div><!-- header container-->
<!-- login modal -->

<div class="modal fade" id="login_form">
	<div class="modal-dialog">
		<div class="modal-content">
		<form action="" method="POST" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Login Below !</h4>
			</div>
			<div class="modal-body">
				<span id="login_msg"></span>
					
					<div class="form-group">
						<label for="">User Name</label>
						<input type="text" class="form-control" id="email" placeholder="User Name...">
					</div>
				<div class="form-group">
						<label for="">Password</label>
						<input type="password" class="form-control" id="password" placeholder="Password...">
					</div>
					
				
				
			</div><!-- modal-body -->
			<div class="modal-footer">
				<button type="button" id="login_btn" class="btn btn-success">Login</button>
			</div>
				
			</form>
		</div>
	</div>
</div>