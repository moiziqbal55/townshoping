<?php include 'connect/db.php'; ?>
<?php include 'connect/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<?php include 'links/head.php'; ?>

	</head>

	<body>
		<?php include 'inc/header.php'; ?>
		<hr>
		<?php include 'inc/nav.php'; ?>
		
		<hr>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<?php include 'inc/left_bar.php'; ?>
				</div><!-- category and bands area -->
				<div class="col-sm-9">
					<?php 
					include @$page;
					 ?>
						
				</div><!-- content col  -->

			</div><!-- row -->
		</div><!-- mian container -->
		<?php include 'inc/footer.php'; ?>

		<?php include 'links/foot.php'; ?>
		<script>
			
			$(document).on("click", "#login_btn", function() {
			    	var email = $("#email").val();
					var password = $("#password").val();
					$.get('ajax/login.php',{em:email,ps:password},function(data){
						$("#login_msg").html(data);
						
					});//ajax get
			});//document
		</script>
		<script>
			$(function () {
			  $('[data-toggle="popover"]').popover()
			})
			</script>
	</body>
</html>