<?php include 'connect/db.php'; ?>
	<?php 
		if (isset($_SESSION['admin_login'])) {
			?>
		<script>
			window.location="admin-panel/";
					</script>
		<?php
		}
		else if (isset($_SESSION['customer_login'])) {
			?>
		<script>
			window.location="customers/";
					</script>
		<?php
		}
		else{


	 ?>

<?php 
		if (isset($_REQUEST['login_admin'])) {
			# code...
			$email = $_REQUEST['email'];
			$password = $_REQUEST['password'];
			if ($email AND $password) {
				$_SESSION['temp_email'] =$email;
			

				$admin = mysqli_query($dbc,"SELECT * FROM admin WHERE email='$email' AND password='$password'");
				
					$customers = mysqli_query($dbc,"SELECT * FROM customers WHERE email='$email' AND password='$password'");

				if (mysqli_num_rows($admin)==1) {
					$msg="Logging...";
					$sts="success";
					$_SESSION['admin_login'] = $email;
					?>
					<script>
						setTimeout(function(){
							window.location='admin-panel/';
						},1000);
					</script>
					<?php
				}else if (mysqli_num_rows($customers)==1) {
					$msg="Logging...";
					$sts="success";
					$_SESSION['customer_login'] = $email;
					?>
					<script>
						setTimeout(function(){
							window.location='customers/';
						},1000);
					</script>
					<?php
					}else{
					$msg="Invalid User Name or Password...";
					$sts="danger";
				}
			}
		}
 ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<?php include 'links/head.php'; ?>
	</head>
	<body style="padding-top: 50px;">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 col-sm-offset-4">
					
						<form method="post">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h3 class="panel-title text-right">Login <button type="submit" class="btn btn-success" name="login_admin"><i class="glyphicon glyphicon-ok"></i></button></h3>
								</div>
								<div class="panel-body">
								<?php 
									if (!empty($msg)) {
										echo "<div class='alert alert-{$sts}'>{$msg}</div>";
									}
								 ?>
									<div class="form-group"><label for="">Email</label><input value="<?php if(!empty($_SESSION['temp_email'])){echo $_SESSION['temp_email'];} ?>" type="text" class="form-control" name="email" placeholder="User Name..."></div>
									<div class="form-group"><label for="">Password</label><input type="password" class="form-control" name="password" placeholder="Password"></div>
								</div><!-- panel body -->
								<div class="panel-footer">
									<a href="index.php" class="btn btn-primary btn-block"><span aria-hidden="true">&larr;</span>  Go Back</a>
								</div>
							</div><!-- panel default -->
						</form><!-- form -->
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->

		<?php include 'links/foot.php'; ?>
	</body>
</html>
<?php }
?>