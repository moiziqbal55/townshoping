<div class="row">
	<?php getPro($dbc,"products"); ?>
</div>