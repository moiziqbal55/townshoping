	<h1>Contact Us</h1>
	<hr>
	<div class="row">
		<div class="col-sm-7">
			
			<hr>
			<div class="panel panel-default">
				<div class="panel-body">
					<form action="" method="POST" class="form-horizontal" role="form">
					<div class="form-group">
						<legend class="text-center">Contact With Us !</legend>
						<hr>
					</div>
			
					<div class="form-group">
						<label class="col-sm-2 control-label">Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control">
						</div>
					</div><!-- field 1 -->
					<div class="form-group">
						<label class="col-sm-2 control-label">Email</label>
						<div class="col-sm-10">
							<input type="email" class="form-control">
						</div>
					</div><!-- field 2 -->
					<div class="form-group">
						<label class="col-sm-2 control-label">Phone</label>
						<div class="col-sm-10">
							<input type="text" class="form-control">
						</div>
					</div><!-- field 2 -->
								<div class="form-group">
						<label class="col-sm-2 control-label">Message</label>
						<div class="col-sm-10">
							<textarea class="form-control" id=""  rows="8"></textarea>
						</div>
					</div><!-- field 3 -->

					<div class="form-group">
						<div class="col-sm-10 col-sm-offset-2">
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
					</div>
			</form>
				</div><!-- panel body -->
			</div><!-- panel default -->
		</div><!-- col 1 -->
		<div class="col-sm-5">
		<br><br>
			<div class="panel panel-default">
				<div class="panel-body">
					<h4>Quick Conatct</h4>
					<hr>
					<div class="row">
					<div class="col-sm-6">
						<b>Office</b><br>
					Shop no. 74 <br>
					MM Alam Road, Lahore <br>
					Phone #: 042-xxxxxx
					youremail@hotmail.com
					</div>
					<div class="col-sm-6">
						<b>Lahore Office</b><br>		
						Office no. 2, 2nd Floor,
						Saf Center, 8-Fna Road,
						Lahore. Ph: 042-xxxxxxxx
						yourmail@gmail.com										
					</div>
					</div>
					<hr>
					<ul>
						<li><b>Email : </b> yourmail@gmail.com	</li>
						<li><b>Phone : </b> 042-xxxxxxx</li>
					</ul>
				</div><!-- panel-body -->
			</div><!-- panel panel-default -->
		</div><!-- col 2 -->
	</div><!-- row -->