
						<div class="row">
					<?php 
					if (isset($_REQUEST['search'])) {
					getPro($dbc,"products",'','',$_REQUEST['user_query']);	
					}else{
						if (!empty($_GET['cat_id']) OR (!empty($_GET['brand_id']))) {
							if (!empty($_GET['brand_id'])) {
								 $_GET['cat_id']="";
							}
							else {
								 $_GET['brand_id']="";
							}
						$brand_id =  $_GET['brand_id'];
						$cat_id = $_GET['cat_id'];

						getPro($dbc,"products",$cat_id,$brand_id);
					}else{
						include 'inc/slider.php';
						getPro($dbc,"products"); }
				}//search else
					 ?>
						</div><!-- product row -->