
<h1>Terms and conditions</h1>
<hr>
<p>
This Privacy Policy governs the manner in which townshoping.com collects, uses, maintains and discloses information collected from users (each, a "User") of the www.townshoping.com website ("Site"). This privacy policy applies to the Site and all products and services offered by townshoping.com.</p>

<h2>Use of The Site</h2>
<p class="text-justify">
You are either at least 18 years of age or are accessing the Site under the supervision of a parent or legal guardian. We grant you a non-transferable and revocable license to use the Site, under the Terms and Conditions described, for the purpose of shopping for personal items sold on the Site. Commercial use or use on behalf of any third party is prohibited, except as explicitly permitted by us in advance. Any breach of these Terms and Conditions shall result in the immediate revocation of the license granted in this paragraph without notice to you.
</p>
<p class="text-justify">

Content provided on this site is solely for informational purposes. Product representations expressed on this Site are those of the vendor and are not made by us. Submissions or opinions expressed on this Site are those of the individual posting such content and may not reflect our opinions.
</p>
<p class="text-justify">

Certain services and related features that may be made available on the Site may require registration or subscription. Should you choose to register or subscribe for any such services or related features, you agree to provide accurate and current information about yourself, and to promptly update such information if there are any changes. Every user of the Site is solely responsible for keeping passwords and other account identifiers safe and secure. The account owner is entirely responsible for all activities that occur under such password or account. Furthermore, you must notify us of any unauthorized use of your password or account. The Site shall not be responsible or liable, directly or indirectly, in any way for any loss or damage of any kind incurred as a result of, or in connection with, your failure to comply with this section.
</p>
<p class="text-justify">

During the registration process you agree to receive promotional emails from the Site. You can subsequently opt out of receiving such promotional e-mails by clicking on the link at the bottom of any promotional email.
</p>
<h2>Personal Information</h2>
<p class="text-justify">
We may collect personal information from Users in a variety of ways, including, but not limited to, when Users visit our site, register on the site place an order subscribe to the newsletter and in connection with other activities, buying products, features or resources we make available on our Site. Users may be asked for, as appropriate, name, email address, mailing address, phone number, credit card information,
</p>
<p class="text-justify">

We will collect personal identification information from Users only if they voluntarily submit such information to us. Users can always refuse to supply personally identification information, except that it may prevent them from engaging in certain Site related activities.
</p>

<h2>Non-Personal Information</h2>
<p class="text-justify">
<b>
We may collect non-personal information about Users whenever they interact with our Site. Non-personal identification information may include the browser name, the type of computer and technical information about Users means of connection to our Site, such as the operating system and the Internet service providers utilized and other similar information.
</b>

<b>Web browser cookies</b>

Our Site may use "cookies" to enhance User experience. User's web browser places cookies on their hard drive for record-keeping purposes and sometimes to track information about them. User may choose to set their web browser to refuse cookies, or to alert you when cookies are being sent. If they do so, note that some parts of the Site may not function properly.
</p>

<h2>Order Acceptance & Pricing</h2>
<p class="text-justify">

Please note that there are cases when an order cannot be processed for various reasons. The Site reserves the right to refuse or cancel any order for any reason at any given time. You may be asked to provide additional verifications or information, including but not limited to phone number and address, before we accept the order.

In order to avoid any fraud with credit or debit cards, we reserve the right to obtain validation of your payment details before providing you with the product and to verify the personal information you shared with us. This verification can take the shape of an identity, place of residence or banking information check. The absence of an answer following such a demand will automatically cause the cancellation of the order within 2 days.We reserve the right to proceed to direct cancellation of an order for which we suspect a risk of fraudulent use of credit or debit card.
</p>

<p class="text-justify">

We are determined to provide the most accurate pricing information on the Site to our users; however, errors may still occur, such as cases when the price of an item is not displayed correctly on the website. As such, we reserve the right to refuse or cancel any order. In the event that an item is mispriced, we may, at our own discretion, either contact you for instructions or cancel your order and notify you of such cancellation. We shall have the right to refuse or cancel any such orders whether or not the order has been confirmed and your credit card charged.
</p>

<h2>Applicable Law and Jurisdiction</h2>
<p class="text-justify">

These Terms and Conditions shall be interpreted and governed by the laws in force in Pakistan. Each party hereby agrees to submit to the jurisdiction of the Pakistan courts and to waive any objections based upon venue.
</p>
<b>
Termination
</b>
<p class="text-justify">


In addition to any other legal or equitable remedies, we may, without prior notice to you, immediately terminate the Terms and Conditions or revoke any or all of your rights granted under the Terms and Conditions. Upon any termination of this Agreement, you shall immediately cease all access to and use of the Site and we shall, in addition to any other legal or equitable remedies, immediately revoke all password(s) and account identification issued to you and deny your access to and use of this Site in whole or in part. Any termination of this agreement shall not affect the respective rights and obligations (including without limitation, payment obligations) of the parties arising before the date of termination. You furthermore agree that the Site shall not be liable to you or to any other person as a result of any such suspension or termination. If you are dissatisfied with the Site or with any terms, conditions, rules, policies, guidelines, or practices in operating the Site, your sole and exclusive remedy is to discontinue using the Site.
</p>